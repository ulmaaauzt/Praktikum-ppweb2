<?php
session_start();
require 'koneksi.php'; // koneksi ke database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nip = $_POST['nip'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE nip='$nip'");
    $data = mysqli_fetch_assoc($query);

    if ($data && password_verify($password, $data['password'])) {
        $_SESSION['nip'] = $data['nip'];
        $_SESSION['role'] = $data['role'];
        echo "<script>alert('Login berhasil!'); window.location='pengisian_cuti.php';</script>";
    } else {
        echo "<script>alert('NIP atau kata sandi salah!'); window.location='login.php';</script>";
    }
}
?>

<!-- Form Login -->
<!DOCTYPE html>
<html>
<head>
  <title>Login e-Cuti</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2 class="text-center mb-4">Login ke e-Cuti</h2>
  <form method="POST">
    <div class="mb-3">
      <label for="nip" class="form-label">NIP</label>
      <input type="text" class="form-control" name="nip" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Kata Sandi</label>
      <input type="password" class="form-control" name="password" required>
    </div>
    <button type="submit" class="btn btn-success w-100">Login</button>
    <p class="mt-3 text-center">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
  </form>
</div>
</body>
</html>

<?php
require 'koneksi.php'; // file koneksi ke database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nip = $_POST['nip'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = 'pegawai';

    // cek apakah NIP sudah ada
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE nip='$nip'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('NIP sudah terdaftar!'); window.location='register.php';</script>";
    } else {
        // pastikan NIP juga ada di tabel pegawai
        $cekPegawai = mysqli_query($conn, "SELECT * FROM pegawai WHERE nip='$nip'");
        if (mysqli_num_rows($cekPegawai) == 0) {
            echo "<script>alert('NIP tidak ditemukan di data pegawai.'); window.location='register.php';</script>";
        } else {
            $simpan = mysqli_query($conn, "INSERT INTO users (nip, password, role) VALUES ('$nip', '$password', '$role')");
            if ($simpan) {
                echo "<script>alert('Registrasi berhasil. Silakan login.'); window.location='login.php';</script>";
            } else {
                echo "<script>alert('Gagal mendaftar!');</script>";
            }
        }
    }
}
?>

<!-- Form Register -->
<!DOCTYPE html>
<html>
<head>
  <title>Daftar Akun</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2 class="text-center mb-4">Buat Akun e-Cuti</h2>
  <form method="POST">
    <div class="mb-3">
      <label for="nip" class="form-label">NIP</label>
      <input type="text" class="form-control" name="nip" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Kata Sandi</label>
      <input type="password" class="form-control" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Daftar</button>
    <p class="mt-3 text-center">Sudah punya akun? <a href="login.php">Login di sini</a></p>
  </form>
</div>
</body>
</html>

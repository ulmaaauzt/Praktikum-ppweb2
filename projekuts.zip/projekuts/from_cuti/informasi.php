<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Informasi - Sistem e-Cuti</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Icon Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="container mt-5">
      <h2 class="text-center mb-4">Informasi Sistem e-Cuti</h2>
      <p class="text-center">Sistem e-Cuti adalah platform digital yang memungkinkan pegawai untuk mengajukan, memantau, dan mengelola cuti mereka dengan cara yang lebih efisien dan transparan. Sistem ini mengoptimalkan pengajuan cuti dengan antarmuka yang mudah digunakan dan fitur yang lengkap.</p>

      <!-- Sejarah dan Tujuan -->
      <section id="sejarah">
        <h3 class="mt-4 mb-3">Sejarah dan Tujuan Sistem</h3>
        <p>Sistem e-Cuti dikembangkan untuk mempermudah pengelolaan proses pengajuan cuti di perusahaan. Sebelumnya, pengajuan cuti dilakukan secara manual dan membutuhkan banyak waktu serta tenaga. Dengan adanya sistem ini, pegawai dapat mengajukan cuti secara online, memantau sisa jatah cuti, dan memperoleh persetujuan dari atasan secara efisien.</p>
        <p>Tujuan utama dari pengembangan sistem ini adalah untuk meningkatkan produktivitas dan transparansi dalam pengelolaan cuti, serta mengurangi beban administratif bagi HRD dan pegawai.</p>
      </section>

      <!-- Fitur Utama -->
      <section id="fitur" class="mt-5">
        <h3 class="mb-3">Fitur Utama Sistem e-Cuti</h3>
        <p>Sistem e-Cuti dilengkapi dengan berbagai fitur yang dapat membantu pegawai dalam mengajukan dan memantau cuti mereka, antara lain:</p>
        <div class="row">
          <div class="col-md-6">
            <ul class="list-unstyled">
              <li><i class="bi bi-check-circle me-2 text-success"></i> <strong>Pengajuan Cuti yang Mudah</strong>: Pegawai dapat mengajukan cuti dengan mengisi form secara digital tanpa perlu dokumen fisik.</li>
              <li><i class="bi bi-check-circle me-2 text-success"></i> <strong>Pantau Jatah Cuti Anda</strong>: Pegawai dapat memantau jatah cuti tahunan yang masih tersedia.</li>
              <li><i class="bi bi-check-circle me-2 text-success"></i> <strong>Persetujuan Cuti Secara Efisien</strong>: Atasan dapat memberikan persetujuan atau penolakan langsung melalui sistem tanpa bertatap muka.</li>
              <li><i class="bi bi-check-circle me-2 text-success"></i> <strong>Laporan Cuti Lengkap</strong>: Sistem menyimpan riwayat pengajuan cuti yang dapat diakses kapan saja.</li>
            </ul>
          </div>
          <div class="col-md-6">
            <img src="img/1-Rapat.webp" class="img-fluid rounded" alt="Fitur Sistem e-Cuti">
          </div>
        </div>
      </section>

      <!-- Cara Penggunaan -->
      <section id="cara" class="mt-5">
        <h3 class="mb-3">Cara Penggunaan Sistem e-Cuti</h3>
        <p>Berikut adalah langkah-langkah mudah untuk menggunakan sistem e-Cuti:</p>
        <div class="row">
          <div class="col-md-6">
            <h5>Langkah 1: Login ke Sistem</h5>
            <p>Masukkan username dan password Anda untuk mengakses halaman utama sistem.</p>
            <h5>Langkah 2: Cek Jatah Cuti</h5>
            <p>Periksa jumlah cuti yang Anda miliki sebelum mengajukan permohonan cuti.</p>
            <h5>Langkah 3: Ajukan Cuti</h5>
            <p>Isi formulir pengajuan cuti dengan tanggal yang diinginkan dan alasan cuti yang valid.</p>
            <h5>Langkah 4: Menunggu Persetujuan</h5>
            <p>Pengajuan Anda akan diverifikasi dan disetujui oleh atasan sesuai dengan kebijakan perusahaan.</p>
            <h5>Langkah 5: Riwayat Cuti</h5>
            <p>Lihat status dan riwayat cuti Anda melalui sistem.</p>
          </div>
          <div class="col-md-6">
            <img src="img/caracuti.jpg" class="img-fluid rounded" alt="Cara Penggunaan e-Cuti">
          </div>
        </div>
      </section>

      <!-- Keamanan dan Privasi -->
      <section id="keamanan" class="mt-5">
        <h3 class="mb-3">Keamanan dan Privasi</h3>
        <p>Keamanan data pengguna adalah prioritas utama bagi sistem e-Cuti. Semua data yang Anda masukkan ke dalam sistem ini akan dilindungi dengan enkripsi tingkat tinggi. Kami memastikan bahwa informasi pribadi Anda hanya dapat diakses oleh pihak yang berwenang, dan tidak akan dibagikan kepada pihak ketiga tanpa izin.</p>
        <p>Setiap transaksi dan pengajuan cuti dilacak dengan sistem audit yang transparan, sehingga setiap perubahan dapat dipantau dan dianalisis untuk memastikan keamanan dan akurasi data.</p>
      </section>

      <!-- Penutupan dan Call-to-Action -->
      <section id="penutupan" class="mt-5 text-center">
        <h4>Mulai Gunakan Sistem e-Cuti Sekarang!</h4>
        <p>Dengan sistem ini, pengajuan cuti Anda akan lebih mudah dan transparan. Jangan ragu untuk mengajukan cuti sekarang juga.</p>
        <a href="../from_cuti/pengajuan_cuti/login.php" class="btn btn-primary btn-lg">Ajukan Cuti Sekarang</a>
      </section>

      <!-- Kembali ke Halaman Utama -->
      <div class="text-center mt-5">
        <a href="indexecuti.php" class="btn btn-secondary btn-lg">Kembali ke Halaman Utama</a>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>

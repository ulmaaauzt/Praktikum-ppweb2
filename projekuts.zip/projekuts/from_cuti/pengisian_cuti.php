<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-CUTI</title>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- icon bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  </head>
  <body>

  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
  <!-- Logo dan Teks Header di sisi kiri -->
  <div class="d-flex align-items-center gap-3">
    <img src="img/ecuti.jpg" alt="Logo" style="height: 80px;">
    <div class="d-flex flex-column">
      <h1 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; font-weight: 700; color: #2c3e50; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); margin: 0;">
        Sistem Pengajuan Cuti
      </h1>
      <h5 style="font-family: 'Merriweather', serif; margin: 0;">
        Ajukan Cuti Anda dengan Mudah dan Cepat
      </h5>
    </div>
  </div>

    <!-- navbar -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" aria-current="page" href="#home">Beranda</a>
            <a class="nav-link" href="#about">Informasi</a>
            <a class="nav-link" href="#panduan">Panduan</a>
            <a class="nav-link" href="#dashboard">Pengajuan</a>
            <a class="nav-link" href="#contact">Contact</a>
          </div>
        </div>  
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
  </div>
</div><br>
    </nav> 
    <!-- selamat datang -->
    <div class="container d-flex flex-column justify-content-center align-items-center vh-100">
      <h1 class="mb-4 text-center">Selamat Datang di Sistem e-Cuti</h1>
      <p class="text-center">Ajukan cuti kerja Anda dengan mudah dan cepat.</p>
      <div class="d-flex justify-content-center">
        <a href="#dashboard" class="btn btn-primary btn-lg mt-3">Ajukan Cuti Sekarang</a>
      </div>
    </div>
    <!-- information -->
    <div>
      <figure id="about" style="padding: 5px; max-width: 600px; margin: 0 auto;">
        <blockquote class="blockquote" style="font-size: 24px; margin: 0; text-align: left;">
            <p>information</p>
        </blockquote>
        <figcaption class="blockquote-footer" style="font-size: 18px; margin-top: 10px; text-align: left;">
          Dapatkan informasi anda, <cite title="Source Title">Segera</cite>
        </figcaption>
    </figure>
      <div class="container my-5">
        <div class="row align-items-center">
          <div class="col-md-6">  
            <img src="img/kerja.jpeg" class="img-fluid rounded" alt="informasi">
          </div>
          <div class="col-md-6">
            <figcaption class="fw" style="font-family: 'Times New Roman', Times, serif;">
              Sistem ini dirancang untuk mempermudah proses pengajuan, persetujuan, dan pemantauan cuti bagi seluruh pegawai di perusahaan. 
              Dengan antarmuka yang intuitif dan fitur-fitur yang memadai, sistem ini mendukung pengelolaan cuti yang lebih efisien dan transparan.
            </figcaption>
            <ul class="list-unstyled mt-4" style="font-family: 'Times New Roman', Times, serif;">
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Pengajuan Cuti yang Mudah</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Pantau Jatah Cuti Anda</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Persetujuan Cuti Secara Efisien</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Laporan Cuti Lengkap</span>
              </li>
            </ul>  
            <figcaption class="fw" style="font-family: 'Times New Roman', Times, serif;">
              Klik tombol di bawah untuk ingin mencari tahu lebih lanjut tentang sistem ini.
            </figcaption>       
            <a href="informasi.php" class="btn btn-primary btn-lg mt-3 d-flex justify-content-center" >informasi lebih lanjut</a> 
          </div>
        </div>
      </div>    
    </div>
    <!-- Panduan -->
    <figure id="panduan" style="padding: 5px; max-width: 600px; margin: 0 auto;">
      <blockquote class="blockquote" style="font-size: 24px; margin: 0; text-align: left;">
          <p>Panduan Cuti</p>
      </blockquote>
      <figcaption class="blockquote-footer" style="font-size: 18px; margin-top: 10px; text-align: left;">
        Berikut adalah langkah-langkah dan informasi penting terkait, <cite title="Source Title">proses pengajuan cuti</cite>
      </figcaption>
  </figure>
  <div class="container py-5">
    <div class="row align-items-center">
      <!-- Kolom Kiri: Scrollspy -->
      <div class="col-md-6">
        <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true"
             class="scrollspy-example p-4 border rounded shadow-sm bg-light" style="height: 320px; overflow-y: auto;" tabindex="0">
          <h6 id="list-item-1">
            <i class="bi bi-box-arrow-in-right me-2 text-primary"></i>
            <strong>Login ke Sistem</strong><br>
            Masukkan username dan password untuk mengakses dashboard pegawai.
          </h6>
          <hr>
          <h6 id="list-item-2">
            <i class="bi bi-calendar-check me-2 text-success"></i>
            <strong>Lihat Jatah Cuti</strong><br>
            Periksa jumlah jatah cuti tahunan Anda yang masih tersedia.
          </h6>
          <hr>
          <h6 id="list-item-3">
            <i class="bi bi-pencil-square me-2 text-warning"></i>
            <strong>Ajukan Cuti</strong><br>
            Isi formulir pengajuan cuti sesuai tanggal dan alasan yang valid.
          </h6>
          <hr>
          <h6 id="list-item-4">
            <i class="bi bi-hourglass-split me-2 text-secondary"></i>
            <strong>Menunggu Persetujuan</strong><br>
            Pengajuan cuti akan diverifikasi dan disetujui oleh atasan.
          </h6>
          <hr>
          <h6 id="list-item-5">
            <i class="bi bi-clock-history me-2 text-info"></i>
            <strong>Riwayat Cuti</strong><br>
            Lihat daftar cuti yang pernah diajukan dan statusnya.
          </h6>
        </div>
      </div>
      <!-- Gambar -->
      <div class="col-md-6 text-center">
        <img src="img/orang.jpeg" class="img-fluid rounded shadow-sm" alt="Ilustrasi Pengajuan Cuti">
      </div>
    </div>
  </div>
  
  
    <!-- Rooms -->  
    <figure class="text-center" id="dashboard">
      <blockquote class="blockquote">
        <p>Dasboard</p>
      </blockquote>
      <figcaption class="blockquote-footer">
       <cite title="Source Title">Kami berkomitmen untuk menjaga keamanan dan kerahasiaan data Anda.
         Semua informasi yang Anda masukkan dalam sistem ini dilindungi dengan enkripsi tingkat tinggi.</cite>
      </figcaption>
    </figure>
      <!-- pengajuan cuti -->
      <div class="row justify-content-center">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow">
        <div class="card-header bg-primary text-white">
          <h3 class="mb-0">Form Pengajuan Cuti</h3>
        </div>
        <div class="card-body">
          <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
          <?php endif; ?>
          <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
          <?php endif; ?>
          
         <form action="proses_pengisian.php" method="POST">

            <div class="mb-3">
              <label for="nip" class="form-label">NIP</label>
              <input type="text" name="nip" class="form-control" id="nip" required>
            </div>

            <div class="mb-3">
              <label for="tgl_mulai" class="form-label">Tanggal Mulai</label>
              <input type="date" name="tgl_mulai" class="form-control" id="tgl_mulai" required>
            </div>

            <div class="mb-3">
              <label for="tgl_selesai" class="form-label">Tanggal Selesai</label>
              <input type="date" name="tgl_selesai" class="form-control" id="tgl_selesai" required>
            </div>

            <div class="mb-3">
              <label for="alasan" class="form-label">Alasan</label>
              <textarea name="alasan" class="form-control" id="alasan" rows="3" required></textarea>
            </div>

            <button type="submit" class="btn btn-success">Kirim Pengajuan</button>

          </form>

        </div>
      </div>
    </div>
  </div>

</div>

<!-- SCRIPT ALERT -->

    <script>
        function showConfirmation() {
            window.location.href = "login.php"; // Arahkan ke halaman utama
        }
    </script>


      <!-- Footer -->
      <footer class="bg-white text-dark py-4 border-top mt-5">
        <div class="container">
          <div class="row align-items-center">
            <!-- Kolom Gambar -->
            <div class="col-md-3 text-center text-md-start mb-3 mb-md-0">
              <img src="img/cuti.jpg" alt="Logo Sistem Cuti" style="height: 100px;">
            </div>
      
            <!-- Kolom Keterangan -->
            <div class="col-md-5">
              <h6 class="fw-bold mb-1">Sistem Cuti Pegawai</h6>
              <p class="mb-0">Aplikasi internal untuk mengelola pengajuan cuti secara digital dan efisien.</p>
              <small class="text-muted">&copy; 2025 eCuti. Semua Hak Dilindungi.</small>
            </div>
      
            <!-- Kolom Navigasi dan Kontak -->
            <div class="col-md-4">
              <h6 class="fw-bold">Kontak & Navigasi</h6>
              <p class="mb-0">Email: support@ecutisistem.com<br>Telp: (021) 1234-5678</p>
            </div>
          </div>
        </div>
      </footer>      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</footer>
</body>
</html>

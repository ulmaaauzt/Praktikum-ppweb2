<?php
session_start();
include 'koneksi.php'; // pastikan file ini menghubungkan ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Amankan input dari SQL Injection
    $nip = mysqli_real_escape_string($conn, $_POST['nip']);
    $tgl_mulai = mysqli_real_escape_string($conn, $_POST['tgl_mulai']);
    $tgl_selesai = mysqli_real_escape_string($conn, $_POST['tgl_selesai']);
    $alasan = mysqli_real_escape_string($conn, $_POST['alasan']);

    // Hitung jumlah hari cuti
    $start = new DateTime($tgl_mulai);
    $end = new DateTime($tgl_selesai);
    $interval = $start->diff($end);
    $jumlah = $interval->days + 1;

    // Simpan ke database
    $sql = "INSERT INTO pengajuan_cuti (tanggal_awal, tanggal_akhir, jumlah, ket, status, nip)
            VALUES (?, ?, ?, ?, 'Menunggu', ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssiss", $tgl_mulai, $tgl_selesai, $jumlah, $alasan, $nip);
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Pengajuan cuti berhasil dikirim.";
            header("Location: dashboard_admin.php"); // ✅ Redirect ke dashboard admin
            exit();
        } else {
            $_SESSION['error_message'] = "Gagal menyimpan data: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Kesalahan pada query SQL.";
    }
    header("Location: index.php#dashboard"); // fallback jika error
    exit();
} else {
    $_SESSION['error_message'] = "Permintaan tidak valid.";
    header("Location: index.php#dashboard");
    exit();
}
?>

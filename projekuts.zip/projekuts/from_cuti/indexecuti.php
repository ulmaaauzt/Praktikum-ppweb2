<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-CUTI</title>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- icon bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    

  </head>
  <body>
  <div class="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
    <img src="img/ecuti.jpg" alt="Hotel Logo" class="img-fluid" style="height: 150px;">
      <div class="container text-center mt-2">
        <h1 style="font-family: 'Playfair Display', serif; font-size: 3rem; font-weight: 700; color: #2c3e50; text-shadow: 1px 1px 2px rgba(0,0,0,0.1);">Sistem Pengajuan Cuti</h1>
        <h4 style="font-family: 'Merriweather', serif;">Ajukan Cuti Anda dengan Mudah dan Cepat</h4>
      </div>
      <div class="d-flex gap-3">
        <a href="register.php" class="btn btn-outline-primary px-4 py-2 rounded-pill d-flex align-items-center gap-2">
          <i class="bi bi-person-plus-fill"></i>Sign In</a>
        <a href="login.php" class="btn btn-primary px-4 py-2 rounded-pill d-flex align-items-center gap-2 text-white">
          <i class="bi bi-box-arrow-in-right"></i>Login</a>
      </div>     
    </div>    
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" aria-current="page" href="#home">Beranda</a>
            <a class="nav-link" href="#about">Informasi</a>
            <a class="nav-link" href="#panduan">Panduan</a>
            <a class="nav-link" href="#dashboard">Dashboard</a>
            <a class="nav-link" href="#contact">Contact</a>
          </div>
        </div>  
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
  </div>
</div><br>
    </nav> 
    <!-- selamat datang -->
    <div class="container d-flex flex-column justify-content-center align-items-center vh-100">
      <h1 class="mb-4 text-center">Selamat Datang di Sistem e-Cuti</h1>
      <p class="text-center">Ajukan cuti kerja Anda dengan mudah dan cepat.</p>
      <div class="d-flex justify-content-center">
        <a href="login.php" class="btn btn-primary btn-lg mt-3">Ajukan Cuti Sekarang</a>
      </div>
    </div>
    <!-- information -->
    <div>
      <figure id="about" style="padding: 5px; max-width: 600px; margin: 0 auto;">
        <blockquote class="blockquote" style="font-size: 24px; margin: 0; text-align: left;">
            <p>information</p>
        </blockquote>
        <figcaption class="blockquote-footer" style="font-size: 18px; margin-top: 10px; text-align: left;">
          Dapatkan informasi anda, <cite title="Source Title">Segera</cite>
        </figcaption>
    </figure>
      <div class="container my-5">
        <div class="row align-items-center">
          <div class="col-md-6">  
            <img src="img/kerja.jpeg" class="img-fluid rounded" alt="informasi">
          </div>
          <div class="col-md-6">
            <figcaption class="fw" style="font-family: 'Times New Roman', Times, serif;">
              Sistem ini dirancang untuk mempermudah proses pengajuan, persetujuan, dan pemantauan cuti bagi seluruh pegawai di perusahaan. 
              Dengan antarmuka yang intuitif dan fitur-fitur yang memadai, sistem ini mendukung pengelolaan cuti yang lebih efisien dan transparan.
            </figcaption>
            <ul class="list-unstyled mt-4" style="font-family: 'Times New Roman', Times, serif;">
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Pengajuan Cuti yang Mudah</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Pantau Jatah Cuti Anda</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Persetujuan Cuti Secara Efisien</span>
              </li>
              <li class="d-flex align-items-center mb-2">
                <i class="fas fa-check-circle me-3 text-success"></i>
                <span>Laporan Cuti Lengkap</span>
              </li>
            </ul>  
            <figcaption class="fw" style="font-family: 'Times New Roman', Times, serif;">
              Klik tombol di bawah untuk ingin mencari tahu lebih lanjut tentang sistem ini.
            </figcaption>       
            <a href="informasi.php" class="btn btn-primary btn-lg mt-3 d-flex justify-content-center" >informasi lebih lanjut</a>   
          </div>
        </div>
      </div>    
    </div>

    <!-- Panduan -->
    <figure id="panduan" style="padding: 5px; max-width: 600px; margin: 0 auto;">
      <blockquote class="blockquote" style="font-size: 24px; margin: 0; text-align: left;">
          <p>Panduan Cuti</p>
      </blockquote>
      <figcaption class="blockquote-footer" style="font-size: 18px; margin-top: 10px; text-align: left;">
        Berikut adalah langkah-langkah dan informasi penting terkait, <cite title="Source Title">proses pengajuan cuti</cite>
      </figcaption>
  </figure>
  <div class="container py-5">
    <div class="row align-items-center">
      <!-- Kolom Kiri: Scrollspy -->
      <div class="col-md-6">
        <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true"
             class="scrollspy-example p-4 border rounded shadow-sm bg-light" style="height: 320px; overflow-y: auto;" tabindex="0">
          <h6 id="list-item-1">
            <i class="bi bi-box-arrow-in-right me-2 text-primary"></i>
            <strong>Login ke Sistem</strong><br>
            Masukkan username dan password untuk mengakses dashboard pegawai.
          </h6>
          <hr>
          <h6 id="list-item-2">
            <i class="bi bi-calendar-check me-2 text-success"></i>
            <strong>Lihat Jatah Cuti</strong><br>
            Periksa jumlah jatah cuti tahunan Anda yang masih tersedia.
          </h6>
          <hr>
          <h6 id="list-item-3">
            <i class="bi bi-pencil-square me-2 text-warning"></i>
            <strong>Ajukan Cuti</strong><br>
            Isi formulir pengajuan cuti sesuai tanggal dan alasan yang valid.
          </h6>
          <hr>
          <h6 id="list-item-4">
            <i class="bi bi-hourglass-split me-2 text-secondary"></i>
            <strong>Menunggu Persetujuan</strong><br>
            Pengajuan cuti akan diverifikasi dan disetujui oleh atasan.
          </h6>
          <hr>
          <h6 id="list-item-5">
            <i class="bi bi-clock-history me-2 text-info"></i>
            <strong>Riwayat Cuti</strong><br>
            Lihat daftar cuti yang pernah diajukan dan statusnya.
          </h6>
        </div>
      </div>
      <!-- Gambar -->
      <div class="col-md-6 text-center">
        <img src="img/orang.jpeg" class="img-fluid rounded shadow-sm" alt="Ilustrasi Pengajuan Cuti">
      </div>
    </div>
  </div>

    <!-- Dashboard -->
      <section id="dashboard" class="py-5 bg-light">
        <div class="container">
          <div class="text-center mb-4">
            <h2 class="fw-bold">Dashboard</h2>
            <p class="text-muted">Pusat kendali Anda untuk seluruh aktivitas cuti</p>
          </div>
          <div class="row align-items-center">
            <div class="col-md-6">
              <p style="text-align: justify;">
                Melalui dashboard ini, Anda dapat dengan mudah memantau <strong>status pengajuan cuti</strong>, 
                mengecek <strong>jatah cuti yang tersisa</strong>, serta meninjau <strong>riwayat pengajuan cuti</strong> 
                sebelumnya secara real-time. Fitur-fitur disusun secara intuitif agar memudahkan Anda dalam 
                mengakses informasi penting dengan cepat dan efisien.
              </p>
              <p style="text-align: justify;">
                Sistem juga menyediakan <strong>notifikasi persetujuan</strong> dan laporan ringkasan cuti Anda, 
                sehingga seluruh proses cuti berjalan lebih <strong>transparan dan terorganisir</strong>.
              </p>
              <p class="text-success fst-italic">
                Dashboard ini dirancang untuk memberikan kontrol penuh kepada Anda sebagai pengguna.
              </p>
            </div>
            <div class="col-md-4 text-center">
              <img src="img/dashboard2.jpeg" class="img-fluid" alt="Dashboard Icon" style="max-height: 400px;" />
            </div>
          </div>
          <div class="text-center mt-4">
            <figcaption class="blockquote-footer">
              <cite title="Source Title">
                Kami berkomitmen menjaga keamanan dan kerahasiaan data Anda. Semua informasi dilindungi dengan enkripsi tingkat tinggi.
              </cite>
            </figcaption>
          </div>
        </div>
      </section>

      <!-- Footer -->
      <footer class="bg-white text-dark py-4 border-top mt-5">
        <div class="container">
          <div class="row align-items-center">
            <!-- Kolom Gambar -->
            <div class="col-md-3 text-center text-md-start mb-3 mb-md-0">
              <img src="img/cuti.jpg" alt="Logo Sistem Cuti" style="height: 100px;">
            </div>
      
            <!-- Kolom Keterangan -->
            <div class="col-md-5">
              <h6 class="fw-bold mb-1">Sistem Cuti Pegawai</h6>
              <p class="mb-0">Aplikasi internal untuk mengelola pengajuan cuti secara digital dan efisien.</p>
              <small class="text-muted">&copy; 2025 eCuti. Semua Hak Dilindungi.</small>
            </div>
      
            <!-- Kolom Navigasi dan Kontak -->
            <div class="col-md-4" id="contact">
              <h6 class="fw-bold">Kontak & Navigasi</h6>
              <p class="mb-0">Email: support@ecutisistem.com<br>Telp: (021) 1234-5678</p>
            </div>
          </div>
        </div>
      </footer>      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</footer>
</body>
</html>
